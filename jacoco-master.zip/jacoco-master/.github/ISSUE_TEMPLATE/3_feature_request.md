---
name: 'Feature request'
about: 'Suggest a feature for JaCoCo'
title:
labels: 'type: enhancement'
assignes:

---

THIS IS A BUG TRACKER ONLY. FOR QUESTIONS PLEASE CHECK FAQ OR USE FORUM:

http://www.jacoco.org/jacoco/trunk/doc/faq.html

https://groups.google.com/forum/?fromgroups=#!forum/jacoco

Please understand that
ISSUES WITHOUT FOLLOWING INFORMATION WILL BE CLOSED WITHOUT COMMENTS!
Thank you for filling feature request!

### Scenario

* JaCoCo version: (from right bottom corner of JaCoCo report)
* Operating system:
* Tool integration: Maven / Ant / CLI / API (for others please report to respective project)
* Description of your use case: (detailed description or executable reproducer, e.g. GitHub repo)

### Current Behaviour

### Wanted Behaviour

### Possible Workarounds
