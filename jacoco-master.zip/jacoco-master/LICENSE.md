License
=======

Copyright (c) 2009, 2021 Mountainminds GmbH & Co. KG and Contributors

The JaCoCo Java Code Coverage Library and all included documentation is made
available by Mountainminds GmbH & Co. KG, Munich. Except indicated below, the
Content is provided to you under the terms and conditions of the Eclipse Public
License Version 2.0 ("EPL"). A copy of the EPL is available at
[https://www.eclipse.org/legal/epl-2.0/](https://www.eclipse.org/legal/epl-2.0/).

Please visit
[http://www.jacoco.org/jacoco/trunk/doc/license.html](http://www.jacoco.org/jacoco/trunk/doc/license.html)
for the complete license information including third party licenses and trademarks.
